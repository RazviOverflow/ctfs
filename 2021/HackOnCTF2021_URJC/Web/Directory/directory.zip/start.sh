#!/bin/sh
docker-compose down
docker-compose up --build
